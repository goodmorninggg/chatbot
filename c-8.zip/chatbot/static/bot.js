document.addEventListener('DOMContentLoaded', function () {
    // Create a div element
const chatbotContainer = document.createElement('div');
chatbotContainer.id = 'chatbot-container'; // Set the ID

// Append the container to the body or any other element
document.body.appendChild(chatbotContainer);
    const scriptTag = document.querySelector('script[src*="bot.js"]'); // Select the script tag
    
    // Get the attribute values
    const botName = scriptTag.getAttribute('chatbotName');
    const username = scriptTag.getAttribute('user');

    
    const botHtmlContent = `
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <style>
   
@import url('https://fonts.googleapis.com/css2?family=Muli:wght@300&display=swap');

 
body {
    font-family: 'Muli', sans-serif;
}
#welcome-message {
   font-size: 18px;
   font-weight: bold;
   text-align: center;
   margin-bottom: 20px;
   color: rgb(46,70,110); 
}

.chat-icon {
   width: 35px;
   height: 30px;
   border-radius: 50%;
   margin-right: 0px; 
    background-color: transparent;

}

.message-container {
   display: flex;
   align-items: flex-start;
   margin: 10px 0;
}

.bot-message-container {
   justify-content: flex-start;
   margin: 5px 0px 6px 5px;
}

.user-message-container {
   justify-content: flex-end;
   margin: 9px 2px 0px 70px;
}

.message-bubble {
   max-width: 70%;
   padding: 10px;
   border-radius: 10px;
   position: relative;
   margin: 0 10px;
}

.chat-message {
   display: flex;
   align-items: center;
   padding: 5px 5px 5px 10px;
   margin: 10px 0;
   border-radius: 10px;
}







#employee-form {
   display: none;
   position: fixed;
   z-index: 1000;
   bottom: 62px;
   right: 50px;
   width: 300px;
   padding: 20px;
   background-color: whitesmoke;
   border: 1px solid #ccc;
   border-radius: 10px;
   box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

#employee-form input[type="text"] {
   width: 95%;
   padding: 10px;
   margin-bottom: 10px;
   border: 1px solid #ccc;
   border-radius: 5px;
}

#employee-form button {
   width: 100%;
   padding: 10px;
   background-color: rgb(46,70,110);
   color: white;
   border: none;
   border-radius: 5px;
   cursor: pointer;
}

#employee-form button:hover {
   background-color:  #005555;
}
        @media only screen and (max-width: 600px) {
         .container-chat{
           height:430px;
           width:300px;
         }
         .chat{
           height:70%;
           width:95%;
         }
         #toggle-chatbot {
           height:2px;
         }
        }
        
        @media only screen and (min-width: 600px) {
          .container-chat{
              height:450px;
              width:300px;
            }
            .chat{
              height:71%;
              width:100%;
            }
            #toggle-chatbot {
              height:2px;
            }
        }
        @media only screen and (min-width: 768px) {
          .container-chat{
              height:500px;
              width:350px;
            }
            .chat{
              height:73%;
              width:100%;
            }
           }
           #toggle-chatbot {
               position: fixed;
               bottom: 20px;
               right: 20px;
               width: 80px;
               height: 80px;
               border-radius: 50%;
               border: none;
               cursor: pointer;
               padding: 0;
               margin: 0;
               z-index: 999;
               overflow: hidden;
               background: none; 
               box-shadow: none;
               transform: translateZ(0);
               will-change: transform;
           }
           #toggle-chatbot.pulse {
               animation: pulse 1.5s infinite;
           }
           @keyframes pulse {
               0% {
                   transform: scale(1) translateZ(0);
               }
               50% {
                   transform: scale(1.05) translateZ(0);
               }
               100% {
                   transform: scale(1) translateZ(0);
               }
           }
        
        .container-chat {
            border: 1px solid #ccc;
            border-radius: 5px;
            overflow-y: hidden;
            overflow-x: hidden;
            position: fixed;
            bottom: 50px;
            right: 50px;
            padding: 13px;
            margin: 10px;
            display: none;
            background-color: whitesmoke;
            height: 500px;
            z-index: 1000; 
            width:350px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
        }
        button {
            margin: 0;
            padding: 0;
        }
        section.bot{
            height: 90%;
        }
        label{
            margin-top: 0%;
        }
        .chat{
            overflow-y: auto;
            border: 1px solid rgb(46,70,110);
            padding: 0px;
            overflow-y: scroll;
            padding-bottom: 10px;
            border-radius: 5px;
            margin-bottom: 5px;
            height:75%;
            width:100%;
            background-color: white;
            /* border-color:  #8ac2b9; */
        }
        .chat::-webkit-scrollbar{
             display: none;
        }
    
        .cat-gory {
            /* border: 1px solid #d4ebe7; */
            padding-bottom: 5px;
            height: 80%;
            max-height: 50px;
            width: 80%;
            overflow-x: hidden;
            margin: 3px 1px 3px 3px;
            white-space: nowrap;
            overflow-y: hidden;
            float: left;
            /* background-color: #d4ebe7; */
        }
        .cat-gory button {
            background-color: rgb(46,70,110);
            border-width: 1px;
            /* border-color: white; */
            color: whitesmoke;
            width: auto;
            border-radius: 5px;
            margin-top: 0px;
            margin-right: 5px;
            padding: 4px;
            transition: box-shadow 0.3s ease; 
        }
        .category-content .scroll-right-button{
            float: left;
            /* border: white; */
            height: 75%;
            margin-bottom: 5px;
            color:whitesmoke;
            margin: 3px 2px 8px 2px;
            width: 7%;
            border-color:  #8ac2b9;
            border-top-right-radius: 5px;
            border-bottom-right-radius: 5px;
            font-size: large;
            background-color:rgb(46,70,110);
        }
        .category-content .scroll-left-button{
            float: left;

            height: 75%;
            width: 7%;
            color: whitesmoke;
            margin: 3px 2px 8px 5px;
            border-color:  rgb(46,70,110);
            border-top-left-radius: 5px;
            border-bottom-left-radius: 5px;
            font-size: large;
            background-color:rgb(46,70,110);
            /* font:black; */
        }
        .bot-name {
           /* background-color: rgb(46, 70, 110); */
           padding: 5px;
           display: flex;
           align-items: center;
           margin: 5px;
           text-align: center;
           color: white;
           display: flex;
           justify-content: space-between;
           align-items: center;
           flex-grow: 1;
           color: white; 
       }
       .bot-name-section {
           display: flex; 
           align-items: center; 
           height: 30px;
           background-color: rgb(46, 70, 110);
           padding: 5px; 
           border-radius: 7px; 
           flex-grow: 1; 
       }
       .bot-controls {
           display: flex; 
           gap: 8px; 
          
           border-radius: 4px;
       }
       .header-container {
           display: flex; 
           align-items: center;
           margin-bottom: 10px;
           height: 30px; 
       }
       .bot-icon {
           width: 50px; 
           height: 35px; 
           margin-right: 8px; 
       }
       .control-button {
           background: whitesmoke;
           border: none;
           font-size: 16px;
           cursor: pointer;
           padding: 5px;
           color: #555;
           border-radius:  5px;
       }
       
       .control-button:hover {
           color: #000;
           background-color: #ddd;
           border-radius: 3px;
           opacity: 0.8;
       }
        .feedback-div {
            background-color: #008080;
            color: #ddd;
            margin-top: 3px;
            float: left;
            clear: both;
            border-radius: 5px;
            height: 50px; 
            width: auto;
            animation: slideUpAndRight 0.167s cubic-bezier(.4,0,.2,0.5);
            margin: 10px;
        }
        .feedback-div>button {
            background-color: #ddd;
            border: none;
            color: black;
            padding: 8px 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            margin: 8px 4px;
            /* cursor: pointer; */
            border-radius: 16px;
            transition: background-color 0.3s ease;
        /* Hover effect */
            :hover {
                background-color: #c0c0c0;
            }
        }
        .star-container {
            display: flex;
            align-items: center;
            margin-top: 10px;
            background-color: #008080;
            color: black;
            margin-top: 3px;
            float:left;
            clear: both;
            border-radius: 5px;
        }
        .star {
            font-size: 24px;
            cursor: pointer;
        }
        .star.selected {
            color: gold; 
        }
        .thankmessage{
            display: flex;
            align-items: center;
            background-color: #008080;
            border-width: 1px;
            color:white;
            margin-top: 3px;
            margin-right: 30%;
            float: left;
            clear: both;
            padding: 5px 10px;
            border-radius: 10px;
            margin: 10px 0; 
            animation: slideUpAndRight 0.167s cubic-bezier(.4,0,.2,0.5);
        }
        .submit_feedback{
            background-color: #3dc553;
            color: black;
            clear: both;
            border-radius: 5px;
            height: 40px;
            width: 60px;
        }
        #emoji-options {
            display: flex;
            justify-content: center;
            margin-top:15px;
            margin-bottom: 15px; 
            max-height: 30px;
        }
        .emoji-options span {
            font-size: 24px;
            cursor: pointer;
            margin: 0 5px;
        }
        .initial-greeting {
            background-color:#008080;
            border-color: black;
            border-width: 1px;
            color: white;
            margin-top: 3px;
            margin-right: 30%;
            float: left;
            clear: both;
            padding: 5px 10px; 
            border-radius: 10px;
            margin: 10px 0; 
        }
        .response-message {
           background-color: rgb(46,70,110);
           color: white;
           justify-content: flex-start;
       }
       #user-message {
           flex: 1;
           padding: 0.5rem;
           border: 1px solid #ccc;
           border-radius: 5px;
           width: 75%;
       }
       
       
        #send-button {
            background-color: rgb(46,70,110);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            margin: 1px -5px 0px 3px;
            cursor: pointer;
            outline: none;
        }
        #send-button:hover {
            background-color: #005555;
        }
        .container-chat.minimized {
           height: 40px; 
           overflow: hidden;
       }
       
       .container-chat.minimized .category-content,
       .container-chat.minimized .chat,
       .container-chat.minimized .user-input {
           display: none;
       }
        .user-message {
           background-color: #f0f0f0;
           color: black;
           order: -1; 
           justify-content: flex-end;
       }
       .chat-message.user-message {
           justify-content: flex-end;
           background-color: transparent;
           margin-left: 23%;
           float: right;
          
           clear: both;
           display: flex;
           flex-direction: row-reverse; 
       }
       .chat-message.user-message .chat-icon {
           order: 2; 
           margin-left: 15px; 
          
       }
       
       .chat-message.user-message .text-container {
           order: 2; 
           background-color: whitesmoke;
           color: black;
       }
        @keyframes slideUp {
            from {
                transform: translateX(44px);
            }
            to {
                transform: none;
            }
        }

        @keyframes slideUpAndRight {
            from {
                transform: translateX(-100px) translateY(44px);
            }
            to {
                transform: none;
            }
        }
        .chat-message.response-message {
           justify-content: flex-start; 
           background-color: transparent; 
           /* margin-right: 30%; */
           padding: 0px 0px 0px 10px;
           float: left;
           clear: both;
           display: flex;
           flex-direction: row; 
       }
       
       .chat-message.response-message .chat-icon {
           order: 1;
           margin: 0px 10px 25px -5px;
       }
       
       .chat-message.response-message .text-container {
           order: 2; 
           background-color: rgb(46, 70, 110);
           color: white;
       }
        .chat-message {
            background-color: #a3c3e4; 
            padding: 5px 10px;
            display: flex;
            align-items: flex-start;
            border-radius: 10px;
            margin: 5px 0px 6px 5px;
        }
        .dropdown-content {
            display: none;
            background-color: #f9f9f9;
            min-width: 200px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            max-height: 200px;
            overflow-y: auto;
            position: absolute; 
            bottom: calc(10%);
        }
        .icon-container {
           margin:3px -8px 0px 9px;
           background-color: transparent;
       }
       
       .text-container {
           padding: 8px 30px 10px 12px;
           border-radius: 8px;
           max-width: 70%;
           margin: 0 -4px 1px 1px;
       }
       
       .user-message .text-container {
           background-color: whitesmoke;
           color: black;
       }
       
       .response-message .text-container {
           background-color:rgb(46, 70, 110);
           color: white;
       }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;   
        }
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        .SubCategoryDiv {
           position: relative;
           top: 0; 
           left: 0;
           transform: none;
           border: 1px solid  rgb(46,70,110);
           border-radius: 5px;
           background-color: #d4ebe7;
           display: none; 
           z-index: 1000;
           cursor: pointer;
           overflow-x: hidden;
           overflow-y: hidden;
           height: auto;
           width: 100%;
           padding: 0px;
           box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
           font-family: 'Muli', sans-serif;
           color: black;
           margin-bottom: 10px; 
       }
       
       .text-container {
           white-space: pre-line;
           text-align: left;
           padding: 8px 12px;
       }
       
       .text-container br {
           display: block;
           content: "";
           margin: 4px 0;
       }
       .subcategorybutton {
           margin: 5px;
           padding: 8px 12px;
           background-color: rgb(46,70,110); 
           border-radius: 4px;
           font-weight: bold;
           color: white; 
           text-align: left;
           border: none; 
           cursor: pointer;
           transition: background-color 0.3s ease; 
       }
       
       .subcategorybutton:hover {
           background-color: #005555;
       }
       .subcategorybutton:disabled {
   opacity: 0.5; 
   cursor: not-allowed; 
   background-color: rgb(46,70,110);}
       
      .closesubcategorydiv {
   margin: 0px 25px;
   padding: 5px 8px; 
   background-color: #bac5e4; 
   border-radius: 4px;
   position: absolute;
   top: 5px; 
   right: 5px;
   height: auto;
   width: fit-content;
   font-size: 12px; 
   color: black; 
   border: none;
   cursor: pointer;
   transition: background-color 0.3s ease; 
   z-index: 1001; 
}
       
       .closesubcategorydiv:hover {
           background-color: #a3b0d1;
       }
       
       .que-container {
           display: flex;
           align-items: center;
           /* margin-bottom: 10px; */
           margin: 5px 0px 6px 30px;
       }
       
       .quebutton {
           background-color: rgb(46,70,110);
           color: white;
           border: none;
           border-radius: 5px;
           /* height: 50px; */
           padding:5px 5px 5px 5px;
           cursor: pointer;
           transition: background-color 0.3s ease;
           margin: 5px 11px 3px 4px;
           width: 80%;
           text-align: left;
       }
       .mitra {
           width: 100%;
           height: 100%; 
           object-fit: cover; 
           display: block;
           position: relative;
           margin: 0;
           padding: 0;
           transition: none !important;
       }
       .quebutton:hover {
           background-color: #005555;
       }
       
       .quediv {
           display: flex;
           flex-direction: column;
           align-items: flex-start;
           margin-bottom: 10px;
           padding: 10px;
           background-color: #f9f9f9;
           border-radius: 10px;
           border: 1px solid #ddd;
       }
       
       .quediv .chat-icon {
           width: 35px;
           height: 30px;
           border-radius: 50%;
           margin-right: 100px;
       }
       .message-bubble user-message{
           color: white;
           border: none;
           border-radius: 5px;
           padding:5px 5px 5px 5px;
           cursor: pointer;
           transition: background-color 0.3s ease;
           margin: 5px 11px 3px 4px;
           width: 80%;
           text-align: left;
       }

</style>
    <div id="notification-banner"></div>

    <button id="toggle-chatbot"> <img src="http://172.22.5.34:5000/static/bot_icon.png" class="mitra"></button>

    <div id="employee-form">
       
    <div id="welcome-message">
        Welcome! How can I assist you today?
    </div>

    
    <form id="employee-id-form">
        <input type="text" name="employee_id" placeholder="Enter Employee ID" required>
        <button type="submit">Submit</button>
    </form>
</div>

    <div class="container-chat" id="draggable-chatbot">
        <div class="header-container">
            <img src="http://172.22.5.34:5000/static/atul_logo.png" alt="Bot Icon" class="bot-icon">
            <div class="bot-name-section">
                <div class="bot-name">
                    <b>{{ chatbot.name }}</b>
                    <div class="bot-controls">
                        <button id="minimize-button" class="control-button">&#8211;</button>
                        <button id="close-button" class="control-button">&#10005;</button>
                    </div>
                </div>
                
            </div>
        </div>
    <div class="bot-name"><b></b></div>

    <div class="category-content">
    <button id="scroll-left-button" class="scroll-left-button">&#9664;</button>
    <div class="cat-gory" id="cat-gory"></div>
    <button id="scroll-right-button" class="scroll-right-button">&#9654;</button>
</div>


<div class="chat" id="chat" user="{{ username }}" data-chatbot="{{ chatbot }}"></div>


<div class="user-input">
    <input type="text" id="user-message" placeholder="Enter a question...">
    <div class="dropdown-content" id="dropdown-content"></div>
    <button id="send-button">Send</button>
</div>
</div>

    `;
    chatbotContainer.innerHTML = botHtmlContent;
    const botNameElement = document.querySelector('.bot-name b');
    botNameElement.innerHTML = botName;
    // Chatbox DOM elements
    const chatbot = document.getElementById('draggable-chatbot');
    const toggleButton = document.getElementById('toggle-chatbot');
    const notificationBanner = document.getElementById('notification-banner');
    const employeeForm = document.getElementById('employee-form');


    
    function startPulsating() {
        toggleButton.classList.add('pulse');
    }

    
    function stopPulsating() {
        toggleButton.classList.remove('pulse');
    }
  

const minimizeButton = document.getElementById('minimize-button');
minimizeButton.addEventListener('click', () => {
const chatContainer = document.querySelector('.container-chat');
chatContainer.classList.toggle('minimized');


const toggleButton = document.getElementById('toggle-chatbot');
if (chatContainer.classList.contains('minimized')) {
    toggleButton.style.display = 'block'; 
} else {
    toggleButton.style.display = 'block'; 
}
});

function toggleChatbot() {
const chatContainer = document.querySelector('.container-chat');
const toggleButton = document.getElementById('toggle-chatbot');

if (chatContainer.classList.contains('minimized')) {
    
    chatContainer.classList.remove('minimized');
    toggleButton.style.display = 'block'; 
} else if (chatbot.style.display === 'none' || chatbot.style.display === '') {
    
    chatbot.style.display = 'block';
    stopPulsating();
    employeeForm.style.display = 'none';
} else {
    
    chatContainer.classList.add('minimized');
    toggleButton.style.display = 'block';
}
}


toggleButton.addEventListener('click', () => {
const chatContainer = document.querySelector('.container-chat');
const botName = document.querySelector('.bot-name');

if (chatContainer.classList.contains('minimized')) {
    // Restore the chatbot if it is minimized
    chatContainer.classList.remove('minimized');
    toggleButton.style.display = 'block'; 
} else if (chatbot.style.display === 'block') {
    // If chatbot is open, minimize it
    chatContainer.classList.add('minimized');
    toggleButton.style.display = 'block'; 
} else if (employeeForm.style.display === 'none' || employeeForm.style.display === '') {
    
    employeeForm.style.display = 'block';
    stopPulsating(); 
} else {
    
    employeeForm.style.display = 'none';
    startPulsating(); 
}
});
const closeButton = document.getElementById('close-button');
closeButton.addEventListener('click', () => {
const chatContainer = document.querySelector('.container-chat');
const toggleButton = document.getElementById('toggle-chatbot');
const chat = document.getElementById('chat');

chatContainer.style.display = 'none';


chat.innerHTML = '';


toggleButton.style.display = 'block';
startPulsating();

toggleButton.addEventListener('click', () => {
    if (chatContainer.style.display === 'none') {
        employeeForm.style.display = 'block';
        stopPulsating();
    }
});
});

const employeeIdForm = document.getElementById('employee-id-form');
employeeIdForm.addEventListener('submit', function (e) {
e.preventDefault();

const employeeId = document.querySelector('input[name="employee_id"]').value;


fetch('http://172.22.5.34:5000/submit_employee_id', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `employee_id=${employeeId}`,
})
.then(response => response.json())
.then(data => {
    if (data.status === 'success') {
        employeeForm.style.display = 'none';
        toggleChatbot();
    } else {
        alert('Error: ' + data.message);
    }
})
.catch(error => {
    console.error('Error submitting employee ID:', error);
    alert('An error occurred. Please try again.');
});
});
    startPulsating();

    notificationBanner.style.display = 'block';
    setTimeout(() => {
        notificationBanner.style.display = 'none';
    },3000);
    const catGory = document.getElementById('cat-gory');
    const scrollLeftButton = document.getElementById('scroll-left-button');
    const scrollRightButton = document.getElementById('scroll-right-button');

    scrollLeftButton.addEventListener('click', () => {
        catGory.scrollBy({
            top: 0,
            left: -100, 
            behavior: 'smooth'
        });
    });
    scrollRightButton.addEventListener('click', () => {
        catGory.scrollBy({
            top: 0,
            left: 100,
            behavior: 'smooth'
        });
    });
    let isFirstToggle = true; 
   
    function scrollChatHistoryToBottom() {
        const chat = document.getElementById('chat');
        chat.scrollTop = chat.scrollHeight;
    }

document.addEventListener('DOMContentLoaded', function () {
    const catGory = document.getElementById('cat-gory');
    const chat = document.getElementById('chat');
    const dropdownContent = document.getElementById('dropdown-content');
    const inputField = document.getElementById('user-message');
    const sendButton = document.getElementById('send-button');
    let trainingData = []; 
    let categories=[];
    let questionCount = 0;

function sendMessage() {
    var userMessage = inputField.value.trim();
    if (userMessage !== '') {
       
        displayMessage(userMessage, true);

       
        const botResponse = "Thank you! Please ask relevant information.";
        displayMessage(botResponse, false);
        scrollChatHistoryToBottom();

        inputField.value = '';
        dropdownContent.style.display = 'none';
        sendButton.style.display = 'inline'; 
    }
}

inputField.addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        sendMessage(); 
    }
});
    if(catGory){
        const username = chat.getAttribute('user');

        fetch(`http://172.22.5.34:5000/get_categories/${chatbotName}/${username}`)
                .then(response => response.json())
                .then(data => {
                    categories= data;
                  
                    const categoryElement = document.createElement('button');
                    categoryElement.textContent = 'All';
                    catGory.appendChild(categoryElement); 
                    iscreated=true;
                    categoryElement.addEventListener('click', function () {
                        chat.innerHTML = '';
                    
                        inputField.value = '';
                        dropdownContent.innerHTML = '';

                        displayQuestions('All');
                    });
                        

                    categories.forEach(categories => {
                        const categoryElement = document.createElement('button');
                        categoryElement.textContent = categories;
                        catGory.appendChild(categoryElement);

                      
                        categoryElement.addEventListener('click', function () {
                        
                            chat.innerHTML = '';

                            inputField.value = '';
                            dropdownContent.innerHTML = '';

                            displayQuestions(categories, true);
                        });
                    });
                })
                .catch(error => {
                    console.error('Error fetching categories:', error);
                });
    }
    function displayMessage(message, isUserMessage) {
const chat = document.getElementById('chat');
const messageContainer = document.createElement('div');
messageContainer.classList.add('chat-message');

if (isUserMessage) {
    messageContainer.classList.add('user-message');
} else {
    messageContainer.classList.add('response-message');
}

const icon = document.createElement('img');
icon.src = isUserMessage ? "http://172.22.5.34:5000/static/user_icon.png" : "http://172.22.5.34:5000/static/bot_icon.png";
icon.alt = isUserMessage ? "User Icon" : "Bot Icon";
icon.classList.add('chat-icon');
messageContainer.appendChild(icon);

const textContainer = document.createElement('div');
textContainer.classList.add('text-container');
textContainer.textContent = message;
messageContainer.appendChild(textContainer);

chat.appendChild(messageContainer);

chat.scrollTop = chat.scrollHeight;
}
    if (chat){
    
        const username = chat.getAttribute('user');

        displayQuestions("",false)

        function displayFeedback() {
            const feedbackDiv = document.createElement('div');
            feedbackDiv.classList.add('feedback-div');

            const feedbackMessage = document.createElement('p');
            feedbackMessage.textContent = "Is there anything else I can help you with?";
            feedbackDiv.appendChild(feedbackMessage);

            const yesButton = document.createElement('button');
            yesButton.textContent = 'Yes';
            yesButton.classList.add('yesButton');
            yesButton.addEventListener('click', function() {
                chat.removeChild(feedbackDiv);
                chat.addEventListener('DOMNodeInserted', incrementQuestionCount); 
                displayMessage("Continue",true);
            });
            feedbackDiv.appendChild(yesButton);

            const noButton = document.createElement('button');
            noButton.textContent = 'No';
            noButton.classList.add('noButton');
            noButton.addEventListener('click', function() {
                chat.removeChild(feedbackDiv); 

                displayMessage("Your feedback is essential for us to improve. Please take a moment to rate your experience.",true);
                const starContainer = document.createElement('div');
                starContainer.classList.add('star-container');
                let selectedStars = 0;
                function handleStarSelection(starValue) {
                    selectedStars = starValue;
                    const stars = document.querySelectorAll('.star');
                    stars.forEach((star, index) => {
                        if (index < starValue) {
                            star.classList.add('selected');
                        } else {
                            star.classList.remove('selected');
                        }
                    });
                }

                let starsSubmitted = false;
                function handleStarSelection(starValue) {
                    if (!starsSubmitted) {
                        selectedStars = starValue;
                        const stars = document.querySelectorAll('.star');
                        stars.forEach((star, index) => {
                            if (index < starValue) {
                                star.classList.add('selected');
                            } else {
                                star.classList.remove('selected');
                            }
                        });
                    }
                }
            
                for (let i = 1; i <= 5; i++) {
                    const star = document.createElement('span');
                    star.textContent = '★';
                    star.classList.add('star');
                    star.dataset.value = i;
                    star.addEventListener('click', () => handleStarSelection(i));
                    starContainer.appendChild(star);  
                }
                const submitButton = document.createElement('button');
                submitButton.classList.add('submit_feedback')
                submitButton.textContent = 'Submit';
                submitButton.addEventListener('click', function() {
                    if (selectedStars > 0) {
                    const thankYouMessage = document.createElement('p');
                    thankYouMessage.classList.add('thankmessage')
                    thankYouMessage.textContent = "Thank you for your valuable feedback!";
                    starContainer.removeChild(submitButton)
                    chat.appendChild(thankYouMessage);
                    chat.scrollTop = chat.scrollHeight;
                    starsSubmitted = true;

                    const stars = document.querySelectorAll('.star');
                    stars.forEach(star => {
                        star.removeEventListener('click', handleStarSelection); });
                    }
                });
                starContainer.appendChild(submitButton);
                chat.appendChild(starContainer);
                chat.scrollTop = chat.scrollHeight;
            });
            feedbackDiv.appendChild(noButton);
            chat.appendChild(feedbackDiv);
           
            chat.removeEventListener('DOMNodeInserted', incrementQuestionCount);
        }
        function checkQuestionCount() {
            
            if (questionCount === 9) {
                displayFeedback();
            }
        }
        function incrementQuestionCount() {
            questionCount++;
            checkQuestionCount();
        }
        function displayQuestions(category,iscategory) {
            if(iscategory==true){
                fetch(`http://172.22.5.34:5000/fetch_data_with_category/${chatbotName}/${username}/${category}`)
                .then(response => response.json())
                .then(data => {
                    trainingData = data;
                    displaysubcategory(category)
                   updateDropdown();
                });
            }
            else{
                fetch(`http://172.22.5.34:5000/fetch_previous_data/${chatbotName}/${username}`)
                .then(response => response.json())
                .then(data => {
                   
                    trainingData = data;
                    updateDropdown();
                });
            }
            function updateDropdown() {
               
                dropdownContent.innerHTML = '';

                trainingData.forEach(entry => {
                    const que = entry.question;
                    const optionElement = document.createElement('a');
                    optionElement.textContent = que;
                    optionElement.addEventListener('click', function () {
                       
                        displayMessage(que, true);

                        const response = entry.response;
                        if (response) {
                            displayMessage(response, false);
                            scrollChatHistoryToBottom();
                        }
                        inputField.value = "";
                        dropdownContent.style.display = 'none';
                    });
                    dropdownContent.appendChild(optionElement);
                });
            }
            inputField.addEventListener('keydown', function (event) {
if (event.key === 'Enter') {
    event.preventDefault(); 
    sendMessage(); 
}
});
function sendMessage() {
var userMessage = inputField.value.trim();
if (userMessage !== '') {
    
    displayMessage(userMessage, true);

   
    const botResponse = "Thank you! Please ask relevant information.";
    displayMessage(botResponse, false);

    scrollChatHistoryToBottom();

    inputField.value = '';
    dropdownContent.style.display = 'none';
    sendButton.style.display = 'inline'; 
}
}

 inputField.addEventListener('keyup', function () {
    var inputValue = inputField.value.toLowerCase();
    
    dropdownContent.innerHTML = '';

    trainingData.forEach(entry => {
        var que = entry.question.toLowerCase();

        if (que.includes(inputValue)) {
            const optionElement =document.createElement('a');
            optionElement.textContent = entry.question;
            optionElement.addEventListener('click', function () {
            
                displayMessage(entry.question, true);

               
                var response = entry.response;
                if (response) {
                    
                    displayMessage(response, false);
                    scrollChatHistoryToBottom();
                }
                inputField.value = "";
                dropdownContent.style.display = 'none';
            });
            dropdownContent.appendChild(optionElement);
        }
    });

    if (inputValue.length > 0) {
        dropdownContent.style.display = 'block';

        var isInDropdown = trainingData.some(entry => entry.question.toLowerCase().includes(inputValue));

        sendButton.style.display = isInDropdown ? 'inline' : 'inline';
    }
    else{
        dropdownContent.style.display = 'none';
        sendButton.style.display = 'inline'; 
    }
});

sendButton.addEventListener('click', function () {
    var userMessage = inputField.value.trim();
    if (userMessage !== '') {
        
        displayMessage(userMessage, true);

        const botResponse = "Thank you ! Pleae ask relevant information";
        displayMessage(botResponse, false);

        scrollChatHistoryToBottom();

        inputField.value = '';
        dropdownContent.style.display = 'none';
        sendButton.style.display = 'inline'; 
    }
});
sendButton.addEventListener('click', sendMessage);

chat.addEventListener('DOMNodeInserted', incrementQuestionCount);
}
function displayQueWithSubcategory(subcategory, category) {
const chat = document.getElementById('chat');
const quediv = document.createElement('div');
quediv.classList.add('quediv');
quediv.style.display = 'block';
quediv.dataset.subcategory = subcategory;

const botIcon = document.createElement('img');
botIcon.src = "http://172.22.5.34:5000/static/bot_icon.png";
botIcon.alt = "Bot Icon";
botIcon.classList.add('chat-icon');
quediv.appendChild(botIcon);

const table_name = username + chatbotName;
fetch(`http://172.22.5.34:5000/fetch_questionsWithSubcategory/${table_name}/${category}/${subcategory}`)
    .then(response => response.json())
    .then(data => {
        data.forEach(entry => {
            const que = entry.question;
            const ans = entry.response;

            const quebutton = document.createElement('button');
            quebutton.classList.add('quebutton');
            quebutton.textContent = que;
            quediv.appendChild(quebutton);

            quebutton.addEventListener('click', function () {
                appendMessage(user, que, true); // Use standardized appendMessage
                appendMessage(chatbotName, ans, false); // Use standardized appendMessage
            });
        });

        chat.appendChild(quediv);
        chat.scrollTop = chat.scrollHeight;
    });
}

function appendMessage(sender, message, isUserMessage) {
const chat = document.getElementById('chat');
const messageContainer = document.createElement('div');
messageContainer.classList.add('chat-message');

if (isUserMessage) {
    messageContainer.classList.add('user-message');
} else {
    messageContainer.classList.add('response-message');
}

const icon = document.createElement('img');
icon.src = isUserMessage ? "http://172.22.5.34:5000/static/user_icon.png" : "http://172.22.5.34:5000/static/bot_icon.png";
icon.alt = isUserMessage ? "User Icon" : "Bot Icon";
icon.classList.add('chat-icon');
messageContainer.appendChild(icon);

const textContainer = document.createElement('div');
textContainer.classList.add('text-container');
textContainer.textContent = message;
messageContainer.appendChild(textContainer);

chat.appendChild(messageContainer);
chat.scrollTop = chat.scrollHeight;
}
function displaysubcategory(category) {
const chathistory = document.getElementById('chat');
const subcategorydiv = document.createElement('div');
subcategorydiv.classList.add('SubCategoryDiv');
subcategorydiv.style.display = 'block';

let isDragging = false;
let offsetX, offsetY;

subcategorydiv.addEventListener('mousedown', function (e) {
    isDragging = true;
    offsetY = e.clientY - subcategorydiv.getBoundingClientRect().top;
});

document.addEventListener('mousemove', function (e) {
    if (isDragging) {
        const maxX = chathistory.offsetWidth - subcategorydiv.offsetWidth;
        const maxY = chathistory.offsetHeight - subcategorydiv.offsetHeight;

        let x = e.clientX - offsetX;
        let y = e.clientY - offsetY;

        x = Math.min(maxX, Math.max(0, x));
        y = Math.min(maxY, Math.max(0, y));

        subcategorydiv.style.left = x + 'px';
        subcategorydiv.style.top = y + 'px';
    }
});

document.addEventListener('mouseup', function () {
    isDragging = false;
});

const table_name = username + chatbotName;
fetch(`http://172.22.5.34:5000/fetch_subcategory/${table_name}/${category}`)
    .then(response => response.json())
    .then(data => {
        const subcategories = data.flat();
        let subcategoryElementCreated = false;

        
        const validSubcategories = subcategories.filter(subcategory => subcategory && subcategory.trim() !== '');

        validSubcategories.forEach(subcategory => {
            const subcategoryElement = document.createElement('button');
            subcategoryElement.classList.add('subcategorybutton');
            subcategoryElement.textContent = subcategory;
            subcategorydiv.appendChild(subcategoryElement);
            subcategoryElementCreated = true;

            subcategoryElement.dataset.subcategory = subcategory;

            subcategoryElement.addEventListener('click', function () {
                const subcategory = this.dataset.subcategory;

                const existingQuediv = document.querySelector(`.quediv[data-subcategory="${subcategory}"]`);
                if (existingQuediv) {
                    existingQuediv.remove(); 
                }

                displayQueWithSubcategory(subcategory, category);
            });
        });

        if (subcategoryElementCreated) {
            const closesubcategorydiv = document.createElement('button');
            closesubcategorydiv.textContent = 'X';
            closesubcategorydiv.classList.add('closesubcategorydiv');
            subcategorydiv.appendChild(closesubcategorydiv);
            chathistory.appendChild(subcategorydiv);

            closesubcategorydiv.addEventListener('click', function () {
                chathistory.removeChild(subcategorydiv);
            });
        }
    });
}

     displayQuestions('',false);

     chat.addEventListener('DOMNodeInserted', incrementQuestionCount);
     scrollChatHistoryToBottom();
}
});
});