const chatbot = document.getElementById('draggable-chatbot');
const toggleButton = document.getElementById('toggle-chatbot');
const notificationBanner = document.getElementById('notification-banner');
const employeeForm = document.getElementById('employee-form');



function startPulsating() {
    toggleButton.classList.add('pulse');
}


function stopPulsating() {
    toggleButton.classList.remove('pulse');
}


const minimizeButton = document.getElementById('minimize-button');
minimizeButton.addEventListener('click', () => {
const chatContainer = document.querySelector('.container-chat');
chatContainer.classList.toggle('minimized');


const toggleButton = document.getElementById('toggle-chatbot');
if (chatContainer.classList.contains('minimized')) {
toggleButton.style.display = 'block'; 
} else {
toggleButton.style.display = 'block'; 
}
});

function toggleChatbot() {
const chatContainer = document.querySelector('.container-chat');
const toggleButton = document.getElementById('toggle-chatbot');

if (chatContainer.classList.contains('minimized')) {

chatContainer.classList.remove('minimized');
toggleButton.style.display = 'block'; 
} else if (chatbot.style.display === 'none' || chatbot.style.display === '') {

chatbot.style.display = 'block';
stopPulsating();
employeeForm.style.display = 'none';
} else {

chatContainer.classList.add('minimized');
toggleButton.style.display = 'block';
}
}


toggleButton.addEventListener('click', () => {
const chatContainer = document.querySelector('.container-chat');
const botName = document.querySelector('.bot-name');

if (chatContainer.classList.contains('minimized')) {
// Restore the chatbot if it is minimized
chatContainer.classList.remove('minimized');
toggleButton.style.display = 'block'; 
} else if (chatbot.style.display === 'block') {
// If chatbot is open, minimize it
chatContainer.classList.add('minimized');
toggleButton.style.display = 'block'; 
} else if (employeeForm.style.display === 'none' || employeeForm.style.display === '') {

employeeForm.style.display = 'block';
stopPulsating(); 
} else {

employeeForm.style.display = 'none';
startPulsating(); 
}
});
const closeButton = document.getElementById('close-button');
closeButton.addEventListener('click', () => {
const chatContainer = document.querySelector('.container-chat');
const toggleButton = document.getElementById('toggle-chatbot');
const chat = document.getElementById('chat');

chatContainer.style.display = 'none';


chat.innerHTML = '';


toggleButton.style.display = 'block';
startPulsating();

toggleButton.addEventListener('click', () => {
if (chatContainer.style.display === 'none') {
    employeeForm.style.display = 'block';
    stopPulsating();
}
});
});

const employeeIdForm = document.getElementById('employee-id-form');
employeeIdForm.addEventListener('submit', function (e) {
e.preventDefault();

const employeeId = document.querySelector('input[name="employee_id"]').value;


fetch('/submit_employee_id', {
method: 'POST',
headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
},
body: `employee_id=${employeeId}`,
})
.then(response => response.json())
.then(data => {
if (data.status === 'success') {
    employeeForm.style.display = 'none';
    toggleChatbot();
} else {
    alert('Error: ' + data.message);
}
})
.catch(error => {
console.error('Error submitting employee ID:', error);
alert('An error occurred. Please try again.');
});
});
startPulsating();

notificationBanner.style.display = 'block';
setTimeout(() => {
    notificationBanner.style.display = 'none';
},3000);
const catGory = document.getElementById('cat-gory');
const scrollLeftButton = document.getElementById('scroll-left-button');
const scrollRightButton = document.getElementById('scroll-right-button');

scrollLeftButton.addEventListener('click', () => {
    catGory.scrollBy({
        top: 0,
        left: -100, 
        behavior: 'smooth'
    });
});
scrollRightButton.addEventListener('click', () => {
    catGory.scrollBy({
        top: 0,
        left: 100,
        behavior: 'smooth'
    });
});
let isFirstToggle = true; 

function scrollChatHistoryToBottom() {
    const chat = document.getElementById('chat');
    chat.scrollTop = chat.scrollHeight;
}

document.addEventListener('DOMContentLoaded', function () {
const catGory = document.getElementById('cat-gory');
const chat = document.getElementById('chat');
const dropdownContent = document.getElementById('dropdown-content');
const inputField = document.getElementById('user-message');
const sendButton = document.getElementById('send-button');
let trainingData = []; 
let categories=[];
let questionCount = 0;

function sendMessage() {
var userMessage = inputField.value.trim();
if (userMessage !== '') {
   
    displayMessage(userMessage, true);

   
    const botResponse = "Thank you! Please ask relevant information.";
    displayMessage(botResponse, false);
    scrollChatHistoryToBottom();

    inputField.value = '';
    dropdownContent.style.display = 'none';
    sendButton.style.display = 'inline'; 
}
}

inputField.addEventListener('keydown', function (event) {
if (event.key === 'Enter') {
    event.preventDefault();
    sendMessage(); 
}
});
if(catGory){
    const username = chat.getAttribute('user');

    fetch(`/get_categories/${chatbotName}/${username}`)
            .then(response => response.json())
            .then(data => {
                categories= data;
              
                const categoryElement = document.createElement('button');
                categoryElement.textContent = 'All';
                catGory.appendChild(categoryElement); 
                iscreated=true;
                categoryElement.addEventListener('click', function () {
                    chat.innerHTML = '';
                
                    inputField.value = '';
                    dropdownContent.innerHTML = '';

                    displayQuestions('All');
                });
                    

                categories.forEach(categories => {
                    const categoryElement = document.createElement('button');
                    categoryElement.textContent = categories;
                    catGory.appendChild(categoryElement);

                  
                    categoryElement.addEventListener('click', function () {
                    
                        chat.innerHTML = '';

                        inputField.value = '';
                        dropdownContent.innerHTML = '';

                        displayQuestions(categories, true);
                    });
                });
            })
            .catch(error => {
                console.error('Error fetching categories:', error);
            });
}
function displayMessage(message, isUserMessage) {
const chat = document.getElementById('chat');
const messageContainer = document.createElement('div');
messageContainer.classList.add('chat-message');

if (isUserMessage) {
messageContainer.classList.add('user-message');
} else {
messageContainer.classList.add('response-message');
}

const icon = document.createElement('img');
icon.src = isUserMessage ? "/static/user_icon.png" : "/static/bot_icon.png";
icon.alt = isUserMessage ? "User Icon" : "Bot Icon";
icon.classList.add('chat-icon');
messageContainer.appendChild(icon);

const textContainer = document.createElement('div');
textContainer.classList.add('text-container');
textContainer.textContent = message;
messageContainer.appendChild(textContainer);

chat.appendChild(messageContainer);

chat.scrollTop = chat.scrollHeight;
}
if (chat){

    const username = chat.getAttribute('user');

    displayQuestions("",false)

    function displayFeedback() {
        const feedbackDiv = document.createElement('div');
        feedbackDiv.classList.add('feedback-div');

        const feedbackMessage = document.createElement('p');
        feedbackMessage.textContent = "Is there anything else I can help you with?";
        feedbackDiv.appendChild(feedbackMessage);

        const yesButton = document.createElement('button');
        yesButton.textContent = 'Yes';
        yesButton.classList.add('yesButton');
        yesButton.addEventListener('click', function() {
            chat.removeChild(feedbackDiv);
            chat.addEventListener('DOMNodeInserted', incrementQuestionCount); 
            displayMessage("Continue",true);
        });
        feedbackDiv.appendChild(yesButton);

        const noButton = document.createElement('button');
        noButton.textContent = 'No';
        noButton.classList.add('noButton');
        noButton.addEventListener('click', function() {
            chat.removeChild(feedbackDiv); 

            displayMessage("Your feedback is essential for us to improve. Please take a moment to rate your experience.",true);
            const starContainer = document.createElement('div');
            starContainer.classList.add('star-container');
            let selectedStars = 0;
            function handleStarSelection(starValue) {
                selectedStars = starValue;
                const stars = document.querySelectorAll('.star');
                stars.forEach((star, index) => {
                    if (index < starValue) {
                        star.classList.add('selected');
                    } else {
                        star.classList.remove('selected');
                    }
                });
            }

            let starsSubmitted = false;
            function handleStarSelection(starValue) {
                if (!starsSubmitted) {
                    selectedStars = starValue;
                    const stars = document.querySelectorAll('.star');
                    stars.forEach((star, index) => {
                        if (index < starValue) {
                            star.classList.add('selected');
                        } else {
                            star.classList.remove('selected');
                        }
                    });
                }
            }
        
            for (let i = 1; i <= 5; i++) {
                const star = document.createElement('span');
                star.textContent = '★';
                star.classList.add('star');
                star.dataset.value = i;
                star.addEventListener('click', () => handleStarSelection(i));
                starContainer.appendChild(star);  
            }
            const submitButton = document.createElement('button');
            submitButton.classList.add('submit_feedback')
            submitButton.textContent = 'Submit';
            submitButton.addEventListener('click', function() {
                if (selectedStars > 0) {
                const thankYouMessage = document.createElement('p');
                thankYouMessage.classList.add('thankmessage')
                thankYouMessage.textContent = "Thank you for your valuable feedback!";
                starContainer.removeChild(submitButton)
                chat.appendChild(thankYouMessage);
                chat.scrollTop = chat.scrollHeight;
                starsSubmitted = true;

                const stars = document.querySelectorAll('.star');
                stars.forEach(star => {
                    star.removeEventListener('click', handleStarSelection); });
                }
            });
            starContainer.appendChild(submitButton);
            chat.appendChild(starContainer);
            chat.scrollTop = chat.scrollHeight;
        });
        feedbackDiv.appendChild(noButton);
        chat.appendChild(feedbackDiv);
       
        chat.removeEventListener('DOMNodeInserted', incrementQuestionCount);
    }
    function checkQuestionCount() {
        
        if (questionCount === 9) {
            displayFeedback();
        }
    }
    function incrementQuestionCount() {
        questionCount++;
        checkQuestionCount();
    }
    function displayQuestions(category,iscategory) {
        if(iscategory==true){
            fetch(`/fetch_data_with_category/${chatbotName}/${username}/${category}`)
            .then(response => response.json())
            .then(data => {
                trainingData = data;
                displaysubcategory(category)
               updateDropdown();
            });
        }
        else{
            fetch(`/fetch_previous_data/${chatbotName}/${username}`)
            .then(response => response.json())
            .then(data => {
               
                trainingData = data;
                updateDropdown();
            });
        }
        function updateDropdown() {
           
            dropdownContent.innerHTML = '';

            trainingData.forEach(entry => {
                const que = entry.question;
                const optionElement = document.createElement('a');
                optionElement.textContent = que;
                optionElement.addEventListener('click', function () {
                   
                    displayMessage(que, true);

                    const response = entry.response;
                    if (response) {
                        displayMessage(response, false);
                        scrollChatHistoryToBottom();
                    }
                    inputField.value = "";
                    dropdownContent.style.display = 'none';
                });
                dropdownContent.appendChild(optionElement);
            });
        }
        inputField.addEventListener('keydown', function (event) {
if (event.key === 'Enter') {
event.preventDefault(); 
sendMessage(); 
}
});
function sendMessage() {
var userMessage = inputField.value.trim();
if (userMessage !== '') {

displayMessage(userMessage, true);


const botResponse = "Thank you! Please ask relevant information.";
displayMessage(botResponse, false);

scrollChatHistoryToBottom();

inputField.value = '';
dropdownContent.style.display = 'none';
sendButton.style.display = 'inline'; 
}
}

inputField.addEventListener('keyup', function () {
var inputValue = inputField.value.toLowerCase();

dropdownContent.innerHTML = '';

trainingData.forEach(entry => {
    var que = entry.question.toLowerCase();

    if (que.includes(inputValue)) {
        const optionElement =document.createElement('a');
        optionElement.textContent = entry.question;
        optionElement.addEventListener('click', function () {
        
            displayMessage(entry.question, true);

           
            var response = entry.response;
            if (response) {
                
                displayMessage(response, false);
                scrollChatHistoryToBottom();
            }
            inputField.value = "";
            dropdownContent.style.display = 'none';
        });
        dropdownContent.appendChild(optionElement);
    }
});

if (inputValue.length > 0) {
    dropdownContent.style.display = 'block';

    var isInDropdown = trainingData.some(entry => entry.question.toLowerCase().includes(inputValue));

    sendButton.style.display = isInDropdown ? 'inline' : 'inline';
}
else{
    dropdownContent.style.display = 'none';
    sendButton.style.display = 'inline'; 
}
});

sendButton.addEventListener('click', function () {
var userMessage = inputField.value.trim();
if (userMessage !== '') {
    
    displayMessage(userMessage, true);

    const botResponse = "Thank you ! Pleae ask relevant information";
    displayMessage(botResponse, false);

    scrollChatHistoryToBottom();

    inputField.value = '';
    dropdownContent.style.display = 'none';
    sendButton.style.display = 'inline'; 
}
});
sendButton.addEventListener('click', sendMessage);

chat.addEventListener('DOMNodeInserted', incrementQuestionCount);
}
function displayQueWithSubcategory(subcategory, category) {
const chat = document.getElementById('chat');
const quediv = document.createElement('div');
quediv.classList.add('quediv');
quediv.style.display = 'block';
quediv.dataset.subcategory = subcategory;

const botIcon = document.createElement('img');
botIcon.src = "/static/bot_icon.png";
botIcon.alt = "Bot Icon";
botIcon.classList.add('chat-icon');
quediv.appendChild(botIcon);

const table_name = username + chatbotName;
fetch(`/fetch_questionsWithSubcategory/${table_name}/${category}/${subcategory}`)
.then(response => response.json())
.then(data => {
    data.forEach(entry => {
        const que = entry.question;
        const ans = entry.response;

        const quebutton = document.createElement('button');
        quebutton.classList.add('quebutton');
        quebutton.textContent = que;
        quediv.appendChild(quebutton);

        quebutton.addEventListener('click', function () {
            appendMessage(user, que, true); // Use standardized appendMessage
            appendMessage(chatbotName, ans, false); // Use standardized appendMessage
        });
    });

    chat.appendChild(quediv);
    chat.scrollTop = chat.scrollHeight;
});
}

function appendMessage(sender, message, isUserMessage) {
const chat = document.getElementById('chat');
const messageContainer = document.createElement('div');
messageContainer.classList.add('chat-message');

if (isUserMessage) {
messageContainer.classList.add('user-message');
} else {
messageContainer.classList.add('response-message');
}

const icon = document.createElement('img');
icon.src = isUserMessage ? "/static/user_icon.png" : "/static/bot_icon.png";
icon.alt = isUserMessage ? "User Icon" : "Bot Icon";
icon.classList.add('chat-icon');
messageContainer.appendChild(icon);

const textContainer = document.createElement('div');
textContainer.classList.add('text-container');
textContainer.textContent = message;
messageContainer.appendChild(textContainer);

chat.appendChild(messageContainer);
chat.scrollTop = chat.scrollHeight;
}
function displaysubcategory(category) {
const chathistory = document.getElementById('chat');
const subcategorydiv = document.createElement('div');
subcategorydiv.classList.add('SubCategoryDiv');
subcategorydiv.style.display = 'block';

let isDragging = false;
let offsetX, offsetY;

subcategorydiv.addEventListener('mousedown', function (e) {
isDragging = true;
offsetY = e.clientY - subcategorydiv.getBoundingClientRect().top;
});

document.addEventListener('mousemove', function (e) {
if (isDragging) {
    const maxX = chathistory.offsetWidth - subcategorydiv.offsetWidth;
    const maxY = chathistory.offsetHeight - subcategorydiv.offsetHeight;

    let x = e.clientX - offsetX;
    let y = e.clientY - offsetY;

    x = Math.min(maxX, Math.max(0, x));
    y = Math.min(maxY, Math.max(0, y));

    subcategorydiv.style.left = x + 'px';
    subcategorydiv.style.top = y + 'px';
}
});

document.addEventListener('mouseup', function () {
isDragging = false;
});

const table_name = username + chatbotName;
fetch(`/fetch_subcategory/${table_name}/${category}`)
.then(response => response.json())
.then(data => {
    const subcategories = data.flat();
    let subcategoryElementCreated = false;

    
    const validSubcategories = subcategories.filter(subcategory => subcategory && subcategory.trim() !== '');

    validSubcategories.forEach(subcategory => {
        const subcategoryElement = document.createElement('button');
        subcategoryElement.classList.add('subcategorybutton');
        subcategoryElement.textContent = subcategory;
        subcategorydiv.appendChild(subcategoryElement);
        subcategoryElementCreated = true;

        subcategoryElement.dataset.subcategory = subcategory;

        subcategoryElement.addEventListener('click', function () {
            const subcategory = this.dataset.subcategory;

            const existingQuediv = document.querySelector(`.quediv[data-subcategory="${subcategory}"]`);
            if (existingQuediv) {
                existingQuediv.remove(); 
            }

            displayQueWithSubcategory(subcategory, category);
        });
    });

    if (subcategoryElementCreated) {
        const closesubcategorydiv = document.createElement('button');
        closesubcategorydiv.textContent = 'X';
        closesubcategorydiv.classList.add('closesubcategorydiv');
        subcategorydiv.appendChild(closesubcategorydiv);
        chathistory.appendChild(subcategorydiv);

        closesubcategorydiv.addEventListener('click', function () {
            chathistory.removeChild(subcategorydiv);
        });
    }
});
}

 displayQuestions('',false);

 chat.addEventListener('DOMNodeInserted', incrementQuestionCount);
 scrollChatHistoryToBottom();
}
});