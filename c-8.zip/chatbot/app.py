import os
from flask import Flask, render_template, request, redirect, url_for,session,flash,jsonify
import psycopg2
import logging
from flask import send_file
from flask_cors import CORS
import mysql.connector
from mysql.connector import Error

app = Flask(__name__)
CORS(app)

conn = mysql.connector.connect(
        host='172.22.82.82',
        user='audit',
        password='Audit@123',
        database='hra'
        )
conn2 = mysql.connector.connect(
        host='172.22.82.82',
        user='audit',
        password='Audit@123',
        database='hra'
        )
app.secret_key = "234"

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/bot.css')
def send_css():
    return app.send_static_file('bot.css')

from datetime import datetime

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        cursor = conn.cursor()
        cursor.execute("SELECT username, role FROM users WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()

        if user:
            session['username'] = user[0]
            session['role'] = user[1]  

            cursor.execute("INSERT INTO user_login_logs (username, login_time) VALUES (%s, %s)",
                           (username, datetime.now()))
            conn.commit()
            cursor.close()

            if session['role'] == 'admin':
                return redirect(url_for('index')) 
            else:
             
                assigned_bots = get_user_chatbots(username)
                
                if assigned_bots:
                    bot_name, user_name = assigned_bots[0]
                    logging.debug(f"Bot name: {bot_name}, User name: {user_name}")               
                    return redirect(url_for('bot', chatbot_name=bot_name, username=user_name))
                else:
                    flash("No chatbot assigned to you. Please contact the admin.", "error")
                    return redirect(url_for('logout')) 
        else:
            flash('Login failed. Invalid credentials.', 'error')

    return render_template('login.html')

def is_valid_login(username, password):
    cursor = conn.cursor()
    cursor.execute("SELECT username FROM users WHERE username = %s AND password = %s", (username, password))
    user = cursor.fetchone() 
    return user is not None

@app.route('/index', methods=['GET', 'POST'])
def index():
    if 'username' in session:
        user_name = session['username']
        role = session.get('role')

        if role == 'admin':
            # Handle bot assignment for admin
            if request.method == 'POST':
                username = request.form.get('username')
                bot_ids = request.form.getlist('bot_id')  # Get list of selected bot IDs

                print("DEBUG: Assigning bot_ids:", bot_ids, "to user:", username)  # Debugging

                if not bot_ids:  # Validate bot_ids
                    flash("Error: No bots selected!", "error")
                    return redirect(url_for('index'))

                try:
                    cursor = conn.cursor()
                    for bot_id in bot_ids:
                        if not bot_id.isdigit():  # Validate each bot_id
                            flash("Error: Invalid bot selection!", "error")
                            return redirect(url_for('index'))

                        bot_id = int(bot_id)
                        cursor.execute("INSERT INTO user_bot_access (username, bot_id) VALUES (%s, %s)", (username, bot_id))
                    conn.commit()
                    cursor.close()
                    # flash('Bots assigned successfully!', 'success')
                except Exception as e:
                    flash(f"Database error: {str(e)}", "error")
                    return redirect(url_for('index'))

            # Fetch users and bots for the admin view
            cursor = conn.cursor()
            cursor.execute("SELECT username FROM users WHERE role = 'user'")
            users = cursor.fetchall()

            cursor.execute("SELECT id, bot_name FROM chatbots")  # Fetch bot_id and bot_name
            bots = cursor.fetchall()
            cursor.close()

            chatbots = get_all_chatbots()
            return render_template('index.html', chatbots=chatbots, user_name=user_name, role=role, users=users, bots=bots)
        else:
            # Redirect users to their assigned chatbot
            assigned_bots = get_user_chatbots(user_name)
            if assigned_bots:
                bot_name, user_name = assigned_bots[0]
                return redirect(url_for('bot', chatbot_name=bot_name, username=user_name))
            else:
                flash("No chatbot assigned to you.", "error")
                return redirect(url_for('logout'))  # Logout if no bot is assigned
    else:
        return redirect(url_for('login'))

def get_all_chatbots():
    cursor = conn.cursor()
    cursor.execute("SELECT bot_name FROM chatbots")
    chatbot_records = cursor.fetchall()
    cursor.close()

    return [record[0] for record in chatbot_records]

def get_user_chatbots(username):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT c.bot_name, c.user_name 
        FROM user_bot_access u
        JOIN chatbots c ON u.bot_id = c.id
        WHERE u.username = %s
    """, (username,))

    chatbot_records = cursor.fetchall()
    cursor.close()

    return chatbot_records

@app.route('/submit_employee_id', methods=['POST'])
def submit_employee_id():
    if request.method == 'POST':
        employee_id = request.form['employee_id']

        try:
            cur = conn.cursor()
            
            # Check if employee ID exists in emp_master table
            cur.execute("SELECT emp_id FROM emp_master WHERE emp_id = %s", (employee_id,))
            emp_exists = cur.fetchone()
            
            if not emp_exists:
                return jsonify({
                    'status': 'error', 
                    'message': 'Employee ID not found in our records. Please enter a valid ID.'
                })
            
            # Insert the employee ID (no duplicate checking)
            cur.execute("INSERT INTO employees (employee_id) VALUES (%s)", (employee_id,))
            conn.commit()
            
            return jsonify({
                'status': 'success', 
                'message': 'Welcome! How can I assist you today?',
                'redirect': True
            })
            
        except Exception as e:
            return jsonify({'status': 'error', 'message': f"Database error: {str(e)}"})
        finally:
            if cur:
                cur.close()

@app.route('/test-static')
def test_static():
    return f"""
        Bot icon: {url_for('static', filename='bot_icon.png')}<br>
        User icon: {url_for('static', filename='user_icon.png')}<br>
        Logo: {url_for('static', filename='atul_logo.png')}<br>
        <img src="{url_for('static', filename='bot_icon.png')}" alt="Bot Icon Test">
    """
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        cursor = conn.cursor()
        cursor.execute("SELECT username FROM users WHERE username = %s", (username,))
        existing_user = cursor.fetchone()
        cursor.close()

        if existing_user:
            return render_template('register.html', message='Username already exists. Please choose a different one.')
        cursor = conn.cursor()

        cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                       (username, email, password))
        
        conn.commit()
        cursor.close()

        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/create_chatbot', methods=['GET', 'POST'])
def create_chatbot():
    if 'username' in session and session.get('role') == 'admin':
        if request.method == 'POST':
            bot_name = request.form['chatbot_name']
            bot_description = request.form['chatbot_description']
            user_name = session['username']  
            bot_table = user_name + bot_name
            
   
            cursor = conn.cursor()
            cursor.execute("SELECT bot_name FROM chatbots WHERE user_name = %s AND bot_name = %s", (user_name, bot_name))
            existing_bot = cursor.fetchone()

            if existing_bot:
                cursor.close()
                return "A bot with the same name already exists. Please choose a different name."

            cursor.execute("INSERT INTO chatbots (bot_name, user_name, bot_table) VALUES (%s, %s, %s)",
                        (bot_name, user_name, bot_table))
            conn.commit()
            cursor.close()

            cursor2 = conn2.cursor()

            cursor2.execute("CREATE TABLE {} (question VARCHAR(1000), answer VARCHAR(1000) , category varchar(100) , subcategory varchar(300))".format(bot_table))

            conn2.commit()
            cursor2.close()

            return redirect(url_for('index'))
        
        return render_template('create_chatbot.html')

    flash("Access denied! Only admins can create chatbots.", "error")
    return redirect(url_for('index'))

logging.basicConfig(level=logging.DEBUG)

def get_chatbots(user_name):
    try:
        cursor = conn.cursor()

        cursor.execute("SELECT bot_name FROM chatbots WHERE user_name = %s", (user_name,))
        chatbot_records = cursor.fetchall()

        chatbots = [record[0] for record in chatbot_records]

        cursor.close()

        return chatbots
    except Exception as e:
        logging.error(f"Error in get_chatbots: {str(e)}")
        return []

@app.route('/delete_chatbot/<chatbot_name>')
def delete_chatbot(chatbot_name):
    user_name = session['username']

    try:
        delete_bot(chatbot_name,user_name)
        bot_table = user_name + chatbot_name
        delete_bot_table(bot_table)    
            
    except Exception as e:
        logging.error(f"Error in get_chatbots: {str(e)}")
        return redirect(url_for('index'))

    return redirect(url_for('index'))

def delete_bot(bot_name,username):
    cursor = conn.cursor()

    cursor.execute("DELETE FROM chatbots WHERE bot_name=%s AND user_name=%s", (bot_name,username))
    conn.commit()
    cursor.close()

def delete_bot_table(table_name):
    cursor2 = conn2.cursor()

    cursor2.execute("DROP TABLE {}".format(table_name))
    conn2.commit()
    cursor2.close()

@app.route('/edit_chatbot/<chatbot_name>/<username>', methods=['GET', 'POST'])
def edit_chatbot(chatbot_name,username):

    return render_template('edit_chatbot.html', chatbot=chatbot_name,username=username)

@app.route("/train/<chatbot_name>", methods=["POST"])
def train_bot(chatbot_name):
    user_name=session['username']
    table_name=user_name + chatbot_name
    try:
        cursor2 = conn2.cursor()
        training_data = request.json.get("trainingData")

        insert_query1 = """
        INSERT INTO {} (question, answer,category)
        VALUES (%s, %s,%s);
        """.format(table_name)

        insert_query2 = """
        INSERT INTO {} (question, answer,category,subcategory)
        VALUES (%s, %s,%s,%s);
        """.format(table_name)

        for training_item in training_data:
            question = training_item.get("question")
            response = training_item.get("response")
            category=training_item.get("category")
            subcategory=training_item.get("selectedSubCategory")
            if subcategory=='Select Subcategory':
                cursor2.execute(insert_query1, (question, response,category))    
            else:
                cursor2.execute(insert_query2, (question,response,category,subcategory))        
        conn2.commit()
        cursor2.close()

        return jsonify({"message": "Training data stored successfully"})
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/fetch_previous_data/<chatbot_name>/<user_name>')
def fetch_previous_data(chatbot_name,user_name):
    try:
        table_name = user_name + chatbot_name
        cursor2 = conn2.cursor()

        cursor2.execute("SELECT * FROM {} ".format(table_name))

        data = cursor2.fetchall()

        conn2.commit()
        cursor2.close()
        training_data = [{'question': row[0], 'response': row[1]} for row in data]

        return jsonify(training_data)
    except Exception as e:
        logging.error("Error fetching previous data:", str(e))
        return jsonify([]) 
        
@app.route('/fetch_data_with_category/<chatbot_name>/<user_name>/<category>')
def fetch_data_with_category(chatbot_name,user_name,category):
    try:
        table_name=user_name+chatbot_name
        cursor2 = conn2.cursor()

        query = f"SELECT * FROM {table_name} WHERE category = %s;"
        cursor2.execute(query, (category,))
        data=cursor2.fetchall()

        conn2.commit()
        cursor2.close()
        training_data = [{'question': row[0], 'response': row[1]} for row in data]

        return jsonify(training_data)
    except Exception as e:
        return jsonify([]) 

@app.route('/bot/<chatbot_name>/<username>', methods=['GET'])
def bot(chatbot_name,username): 

    return render_template('bot.html',chatbot={'name': chatbot_name},username=username)

@app.route('/1/<chatbot_name>/<username>', methods=['GET'])
def bt1(chatbot_name,username): 

    return render_template('1.html',chatbot={'name': chatbot_name},username=username)

@app.route('/bot.js/<chatbot_name>/<username>', methods=['GET'])
def send_js(chatbot_name, username):
    js_file_path = 'static/bot.js'

    with open(js_file_path, 'r') as file:
        js_content = file.read()

    js_content = js_content.replace('{{chatbotName}}', chatbot_name).replace('{{user}}', username)

    with open('temp_bot.js', 'w') as temp_file:
        temp_file.write(js_content)

    return send_file('temp_bot.js', mimetype='text/javascript')

@app.route('/add_categories/<chatbot_name>', methods=['POST'])
def add_categories(chatbot_name):
    user_name=session['username']
    table_name=user_name + chatbot_name
    try:
        cursor = conn.cursor()     
        categories = request.json.get('categories')  
        for category in categories:        
            insert_query="""INSERT INTO category (bot_table,type_name) VALUES (%s ,%s);"""
            cursor.execute(insert_query,(table_name,category))

        conn.commit()
        cursor.close()

        return jsonify({"message": "Training data stored successfully"})

    except Exception as e:
        return jsonify({"error": str(e)})
    return render_template('edit_chatbot.html',chatbot={'name': chatbot_name})

@app.route('/get_categories/<chatbot_name>/<user_name>')
def get_categories(chatbot_name,user_name):

    table_name = user_name + chatbot_name

    cursor = conn.cursor()

    cursor.execute("SELECT type_name FROM category WHERE bot_table=%s",(table_name,))
    categories = cursor.fetchall()

    conn.commit()
    cursor.close()

    return jsonify(categories)

@app.route('/fetch_subcategory/<table_name>/<category>')
def fetch_subcategory(table_name, category):
    cursor = conn.cursor()
    column_names = [f'subcategory{i}' for i in range(1, 11)]
    subcategories = []

    for column in column_names:
        select_query = f"SELECT {column} FROM category WHERE bot_table=%s AND type_name=%s"
        cursor.execute(select_query, (table_name, category))
        result = cursor.fetchone()
        if result and result[0]:  
            subcategories.append(result[0])

    cursor.close()
    return jsonify(subcategories)
@app.route('/store_subcategories/<table_name>', methods=['POST'])
def store_subcategories(table_name):
    data = request.get_json()
    category = data['category']
    subcategories = data['subcategories']
    cursor = conn.cursor()

    column_names = [f'subcategory{i}' for i in range(1, 10)]

 
    for column, subcategory in zip(column_names, subcategories):
        update_query = f"UPDATE category SET {column}=%s WHERE bot_table=%s AND type_name=%s"
        cursor.execute(update_query, (subcategory, table_name, category))
        conn.commit()

    cursor.close()

    return jsonify({'success': True})

@app.route('/fetch_questionsWithSubcategory/<table_name>/<category>/<subcategory>')
def fetch_questionsWithSubcategory(table_name,category,subcategory):

    cursor2 = conn2.cursor()
    query=f"SELECT question,answer FROM {table_name} WHERE category=%s and subcategory=%s"
    cursor2.execute(query,(category,subcategory))
    data=cursor2.fetchall()
    data = [{'question': row[0], 'response': row[1]} for row in data]

    cursor2.close()
    return jsonify(data)

if __name__ == "__main__":
    # app.run(debug=True)
    app.run(host='172.22.5.34',port=5000)
    
